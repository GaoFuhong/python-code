# Author:Fuhong Gao
import package_test #导入该模块同级下的包（实质是执行该包下的__init__.py文件）

package_test.p_test1.pack_test()

