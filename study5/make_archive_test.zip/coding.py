# Author:Fuhong Gao
name = "你好，世界！"
print(name)